# Mobile 3D Battle Royale — Island Drop

A browser-playable third-person battle royale prototype using HTML, CSS, JavaScript and Three.js.

## Features
- Original procedural low-poly island, trees, rocks, roads and houses
- Player movement and third-person camera
- Seven basic computer-controlled bots
- Shooting, ammo, reload, weapon switch, pickups and health
- Shrinking safe zone, kills counter, remaining bots and win/lose screen
- Mobile joystick, touch camera, fire and action buttons
- Desktop WASD, mouse aim/fire, Space jump, Shift sprint, R reload, Q switch, C crouch
- No API keys, paid APIs, account, or backend

## Run
Open `index.html` in a modern browser with internet access. Three.js loads from jsDelivr CDN, so internet is needed to load the game.

## Publish with GitHub Pages
1. Open repository **Settings** → **Pages**.
2. Select **Deploy from a branch**.
3. Choose `main` and `/ (root)`, then Save.
4. Open the published URL shown by GitHub Pages.

This is a playable prototype, not a commercial-scale or multiplayer game. Orientation locking depends on browser/device support.
